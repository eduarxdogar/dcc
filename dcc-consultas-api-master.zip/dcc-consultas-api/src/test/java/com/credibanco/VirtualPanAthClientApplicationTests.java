package com.credibanco;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VirtualPanAthClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
