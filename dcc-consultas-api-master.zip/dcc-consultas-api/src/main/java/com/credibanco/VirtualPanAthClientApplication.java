package com.credibanco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtualPanAthClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtualPanAthClientApplication.class, args);
	}

}
