package com.credibanco.clients;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.credibanco.dcc.dtos.RequestTerminalDCC;

@Service
public class CyTRestClient {
	
	private final Logger LOG = LoggerFactory.getLogger(CyTRestClient.class);
	
	@Value("${terminal.basic.autentication}")
	private String basicAutorization;
	
	@Value("${dcc.is.terminal.url}")
	private String urlGetIsTerminal;
	
	public Object requestTerminalDCC(RequestTerminalDCC requestTerminal) throws KeyManagementException, KeyStoreException, NoSuchAlgorithmException {
		
			String autorization = "Basic ";
			autorization = autorization + basicAutorization;
			RestTemplate restTemplate = null;
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set(HttpHeaders.AUTHORIZATION, autorization); 
			restTemplate = restTemplateWithoutSSL();
			
			HttpEntity<RequestTerminalDCC> request = new HttpEntity<>(requestTerminal ,headers);	
			try {
				LOG.debug("Method requestTerminalDCC request: {}", requestTerminal);
				ResponseEntity<Object> result = restTemplate.exchange(urlGetIsTerminal, HttpMethod.POST , request, Object.class);
				LOG.debug("Method requestTerminalDCC response: {}", result.getBody());
				return result.getBody();
	
			} catch (HttpClientErrorException | HttpServerErrorException e) {
				LOG.error(e.getMessage());
			}
		return null;
	}
	
	public RestTemplate restTemplateWithoutSSL() throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
		TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
		SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
		SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory(sslContext);
		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(csf).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		return new RestTemplate(requestFactory);
	}

}
