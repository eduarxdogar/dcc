package com.credibanco.dcc.services;

public interface ITerminalConsultaService {
	
	public boolean isTerminalDCC(String terminalID);

}
