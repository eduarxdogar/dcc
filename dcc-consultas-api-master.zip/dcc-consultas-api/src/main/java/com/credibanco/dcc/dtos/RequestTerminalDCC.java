package com.credibanco.dcc.dtos;

import java.util.List;

public class RequestTerminalDCC {
	private String numeroTerminal;
    private List<String> serviciosTerminal;
	public String getNumeroTerminal() {
		return numeroTerminal;
	}
	public RequestTerminalDCC(String numeroTerminal, List<String> serviciosTerminal) {
		super();
		this.numeroTerminal = numeroTerminal;
		this.serviciosTerminal = serviciosTerminal;
	}
	public void setNumeroTerminal(String numeroTerminal) {
		this.numeroTerminal = numeroTerminal;
	}
	public List<String> getServiciosTerminal() {
		return serviciosTerminal;
	}
	public void setServiciosTerminal(List<String> serviciosTerminal) {
		this.serviciosTerminal = serviciosTerminal;
	}
}
