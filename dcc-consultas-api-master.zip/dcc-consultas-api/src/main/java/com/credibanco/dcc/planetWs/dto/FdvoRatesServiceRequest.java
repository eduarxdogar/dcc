//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartnerDetails" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="SubgroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RequestScope" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}RequestScopeType"/&gt;
 *                   &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RatesSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RatesDetails" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="BaseCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RatesProfileID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RatesBand" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *                   &lt;element name="RatesDays" minOccurs="0"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;enumeration value="1"/&gt;
 *                         &lt;enumeration value="2"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "partnerDetails",
    "ratesDetails"
})
@XmlRootElement(name = "FdvoRatesServiceRequest")
public class FdvoRatesServiceRequest {

    @XmlElement(name = "PartnerDetails")
    protected FdvoRatesServiceRequest.PartnerDetails partnerDetails;
    @XmlElement(name = "RatesDetails")
    protected FdvoRatesServiceRequest.RatesDetails ratesDetails;

    /**
     * Obtiene el valor de la propiedad partnerDetails.
     * 
     * @return
     *     possible object is
     *     {@link FdvoRatesServiceRequest.PartnerDetails }
     *     
     */
    public FdvoRatesServiceRequest.PartnerDetails getPartnerDetails() {
        return partnerDetails;
    }

    /**
     * Define el valor de la propiedad partnerDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoRatesServiceRequest.PartnerDetails }
     *     
     */
    public void setPartnerDetails(FdvoRatesServiceRequest.PartnerDetails value) {
        this.partnerDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad ratesDetails.
     * 
     * @return
     *     possible object is
     *     {@link FdvoRatesServiceRequest.RatesDetails }
     *     
     */
    public FdvoRatesServiceRequest.RatesDetails getRatesDetails() {
        return ratesDetails;
    }

    /**
     * Define el valor de la propiedad ratesDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoRatesServiceRequest.RatesDetails }
     *     
     */
    public void setRatesDetails(FdvoRatesServiceRequest.RatesDetails value) {
        this.ratesDetails = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="SubgroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RequestScope" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}RequestScopeType"/&gt;
     *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RatesSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "version",
        "partnerID",
        "subgroupID",
        "merchantName",
        "requestScope",
        "countryCode",
        "ratesSource",
        "msgDateTime",
        "signature"
    })
    public static class PartnerDetails {

        @XmlElement(name = "Version")
        protected String version;
        @XmlElement(name = "PartnerID")
        protected int partnerID;
        @XmlElement(name = "SubgroupID")
        protected int subgroupID;
        @XmlElement(name = "MerchantName")
        protected String merchantName;
        @XmlElement(name = "RequestScope", required = true)
        protected String requestScope;
        @XmlElement(name = "CountryCode")
        protected String countryCode;
        @XmlElement(name = "RatesSource")
        protected String ratesSource;
        @XmlElement(name = "MsgDateTime")
        protected String msgDateTime;
        @XmlElement(name = "Signature")
        protected String signature;

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersion(String value) {
            this.version = value;
        }

        /**
         * Obtiene el valor de la propiedad partnerID.
         * 
         */
        public int getPartnerID() {
            return partnerID;
        }

        /**
         * Define el valor de la propiedad partnerID.
         * 
         */
        public void setPartnerID(int value) {
            this.partnerID = value;
        }

        /**
         * Obtiene el valor de la propiedad subgroupID.
         * 
         */
        public int getSubgroupID() {
            return subgroupID;
        }

        /**
         * Define el valor de la propiedad subgroupID.
         * 
         */
        public void setSubgroupID(int value) {
            this.subgroupID = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMerchantName() {
            return merchantName;
        }

        /**
         * Define el valor de la propiedad merchantName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMerchantName(String value) {
            this.merchantName = value;
        }

        /**
         * Obtiene el valor de la propiedad requestScope.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRequestScope() {
            return requestScope;
        }

        /**
         * Define el valor de la propiedad requestScope.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRequestScope(String value) {
            this.requestScope = value;
        }

        /**
         * Obtiene el valor de la propiedad countryCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCode() {
            return countryCode;
        }

        /**
         * Define el valor de la propiedad countryCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCode(String value) {
            this.countryCode = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesSource.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRatesSource() {
            return ratesSource;
        }

        /**
         * Define el valor de la propiedad ratesSource.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRatesSource(String value) {
            this.ratesSource = value;
        }

        /**
         * Obtiene el valor de la propiedad msgDateTime.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMsgDateTime() {
            return msgDateTime;
        }

        /**
         * Define el valor de la propiedad msgDateTime.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMsgDateTime(String value) {
            this.msgDateTime = value;
        }

        /**
         * Obtiene el valor de la propiedad signature.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSignature() {
            return signature;
        }

        /**
         * Define el valor de la propiedad signature.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSignature(String value) {
            this.signature = value;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="BaseCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RatesProfileID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RatesBand" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
     *         &lt;element name="RatesDays" minOccurs="0"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;enumeration value="1"/&gt;
     *               &lt;enumeration value="2"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "baseCurrencyCode",
        "ratesProfileID",
        "ratesBand",
        "ratesDays"
    })
    public static class RatesDetails {

        @XmlElement(name = "BaseCurrencyCode")
        protected String baseCurrencyCode;
        @XmlElement(name = "RatesProfileID")
        protected String ratesProfileID;
        @XmlElement(name = "RatesBand", defaultValue = "0")
        protected Integer ratesBand;
        @XmlElement(name = "RatesDays", defaultValue = "1")
        protected String ratesDays;

        /**
         * Obtiene el valor de la propiedad baseCurrencyCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBaseCurrencyCode() {
            return baseCurrencyCode;
        }

        /**
         * Define el valor de la propiedad baseCurrencyCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBaseCurrencyCode(String value) {
            this.baseCurrencyCode = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesProfileID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRatesProfileID() {
            return ratesProfileID;
        }

        /**
         * Define el valor de la propiedad ratesProfileID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRatesProfileID(String value) {
            this.ratesProfileID = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesBand.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getRatesBand() {
            return ratesBand;
        }

        /**
         * Define el valor de la propiedad ratesBand.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setRatesBand(Integer value) {
            this.ratesBand = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesDays.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRatesDays() {
            return ratesDays;
        }

        /**
         * Define el valor de la propiedad ratesDays.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRatesDays(String value) {
            this.ratesDays = value;
        }

    }

}
