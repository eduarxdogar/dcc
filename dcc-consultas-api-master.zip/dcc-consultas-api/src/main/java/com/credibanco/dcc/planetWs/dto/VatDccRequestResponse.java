//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="VatDccRequestResult" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "vatDccRequestResult"
})
@XmlRootElement(name = "VatDccRequestResponse", namespace = "http://FdvoWebService.fintrax.com/")
public class VatDccRequestResponse {

    @XmlElement(name = "VatDccRequestResult", namespace = "http://FdvoWebService.fintrax.com/")
    protected String vatDccRequestResult;

    /**
     * Obtiene el valor de la propiedad vatDccRequestResult.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVatDccRequestResult() {
        return vatDccRequestResult;
    }

    /**
     * Define el valor de la propiedad vatDccRequestResult.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVatDccRequestResult(String value) {
        this.vatDccRequestResult = value;
    }

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("VatDccRequestResponse [");
		if (vatDccRequestResult != null) {
			builder.append("vatDccRequestResult=");
			builder.append(vatDccRequestResult);
		}
		builder.append("]");
		return builder.toString();
	}
}
