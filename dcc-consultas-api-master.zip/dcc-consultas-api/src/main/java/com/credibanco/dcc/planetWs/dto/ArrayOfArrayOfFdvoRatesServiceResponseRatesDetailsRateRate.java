//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Rate" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="BaseCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="ForeignCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Rate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="DateEffective" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate", propOrder = {
    "rate"
})
public class ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate {

    @XmlElement(name = "Rate")
    protected List<ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate> rate;

    /**
     * Gets the value of the rate property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rate property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRate().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate }
     * 
     * 
     */
    public List<ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate> getRate() {
        if (rate == null) {
            rate = new ArrayList<ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate>();
        }
        return this.rate;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="BaseCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="ForeignCurrency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Rate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="DateEffective" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "baseCurrencyCode",
        "foreignCurrency",
        "rate",
        "dateEffective"
    })
    public static class Rate {

        @XmlElement(name = "BaseCurrencyCode")
        protected String baseCurrencyCode;
        @XmlElement(name = "ForeignCurrency")
        protected String foreignCurrency;
        @XmlElement(name = "Rate")
        protected String rate;
        @XmlElement(name = "DateEffective")
        protected String dateEffective;

        /**
         * Obtiene el valor de la propiedad baseCurrencyCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBaseCurrencyCode() {
            return baseCurrencyCode;
        }

        /**
         * Define el valor de la propiedad baseCurrencyCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBaseCurrencyCode(String value) {
            this.baseCurrencyCode = value;
        }

        /**
         * Obtiene el valor de la propiedad foreignCurrency.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getForeignCurrency() {
            return foreignCurrency;
        }

        /**
         * Define el valor de la propiedad foreignCurrency.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setForeignCurrency(String value) {
            this.foreignCurrency = value;
        }

        /**
         * Obtiene el valor de la propiedad rate.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRate() {
            return rate;
        }

        /**
         * Define el valor de la propiedad rate.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRate(String value) {
            this.rate = value;
        }

        /**
         * Obtiene el valor de la propiedad dateEffective.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDateEffective() {
            return dateEffective;
        }

        /**
         * Define el valor de la propiedad dateEffective.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDateEffective(String value) {
            this.dateEffective = value;
        }

    }

}
