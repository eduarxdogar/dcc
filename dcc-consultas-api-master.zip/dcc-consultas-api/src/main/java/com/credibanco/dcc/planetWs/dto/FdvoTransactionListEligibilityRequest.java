//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MandatoryFields" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="SubGroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="TID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RequestScope"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;enumeration value="0"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="CurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="POSVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Transactions" type="{http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema}ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "mandatoryFields",
    "transactions"
})
@XmlRootElement(name = "FdvoTransactionListEligibilityRequest", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
public class FdvoTransactionListEligibilityRequest {

    @XmlElement(name = "MandatoryFields", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
    protected FdvoTransactionListEligibilityRequest.MandatoryFields mandatoryFields;
    @XmlElement(name = "Transactions", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
    protected ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction transactions;

    /**
     * Obtiene el valor de la propiedad mandatoryFields.
     * 
     * @return
     *     possible object is
     *     {@link FdvoTransactionListEligibilityRequest.MandatoryFields }
     *     
     */
    public FdvoTransactionListEligibilityRequest.MandatoryFields getMandatoryFields() {
        return mandatoryFields;
    }

    /**
     * Define el valor de la propiedad mandatoryFields.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoTransactionListEligibilityRequest.MandatoryFields }
     *     
     */
    public void setMandatoryFields(FdvoTransactionListEligibilityRequest.MandatoryFields value) {
        this.mandatoryFields = value;
    }

    /**
     * Obtiene el valor de la propiedad transactions.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction }
     *     
     */
    public ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction getTransactions() {
        return transactions;
    }

    /**
     * Define el valor de la propiedad transactions.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction }
     *     
     */
    public void setTransactions(ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction value) {
        this.transactions = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="SubGroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="TID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RequestScope"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;enumeration value="0"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="CurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="POSVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "version",
        "partnerID",
        "subGroupID",
        "tid",
        "merchantName",
        "requestScope",
        "countryCode",
        "currencyCode",
        "msgDateTime",
        "posVersion",
        "signature",
        "mid"
    })
    public static class MandatoryFields {

        @XmlElement(name = "Version", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String version;
        @XmlElement(name = "PartnerID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected int partnerID;
        @XmlElement(name = "SubGroupID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected int subGroupID;
        @XmlElement(name = "TID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String tid;
        @XmlElement(name = "MerchantName", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String merchantName;
        @XmlElement(name = "RequestScope", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema", required = true)
        protected String requestScope;
        @XmlElement(name = "CountryCode", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String countryCode;
        @XmlElement(name = "CurrencyCode", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String currencyCode;
        @XmlElement(name = "MsgDateTime", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String msgDateTime;
        @XmlElement(name = "POSVersion", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String posVersion;
        @XmlElement(name = "Signature", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String signature;
        @XmlElement(name = "MID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String mid;

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersion(String value) {
            this.version = value;
        }

        /**
         * Obtiene el valor de la propiedad partnerID.
         * 
         */
        public int getPartnerID() {
            return partnerID;
        }

        /**
         * Define el valor de la propiedad partnerID.
         * 
         */
        public void setPartnerID(int value) {
            this.partnerID = value;
        }

        /**
         * Obtiene el valor de la propiedad subGroupID.
         * 
         */
        public int getSubGroupID() {
            return subGroupID;
        }

        /**
         * Define el valor de la propiedad subGroupID.
         * 
         */
        public void setSubGroupID(int value) {
            this.subGroupID = value;
        }

        /**
         * Obtiene el valor de la propiedad tid.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTID() {
            return tid;
        }

        /**
         * Define el valor de la propiedad tid.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTID(String value) {
            this.tid = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMerchantName() {
            return merchantName;
        }

        /**
         * Define el valor de la propiedad merchantName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMerchantName(String value) {
            this.merchantName = value;
        }

        /**
         * Obtiene el valor de la propiedad requestScope.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRequestScope() {
            return requestScope;
        }

        /**
         * Define el valor de la propiedad requestScope.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRequestScope(String value) {
            this.requestScope = value;
        }

        /**
         * Obtiene el valor de la propiedad countryCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCode() {
            return countryCode;
        }

        /**
         * Define el valor de la propiedad countryCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCode(String value) {
            this.countryCode = value;
        }

        /**
         * Obtiene el valor de la propiedad currencyCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrencyCode() {
            return currencyCode;
        }

        /**
         * Define el valor de la propiedad currencyCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrencyCode(String value) {
            this.currencyCode = value;
        }

        /**
         * Obtiene el valor de la propiedad msgDateTime.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMsgDateTime() {
            return msgDateTime;
        }

        /**
         * Define el valor de la propiedad msgDateTime.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMsgDateTime(String value) {
            this.msgDateTime = value;
        }

        /**
         * Obtiene el valor de la propiedad posVersion.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPOSVersion() {
            return posVersion;
        }

        /**
         * Define el valor de la propiedad posVersion.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPOSVersion(String value) {
            this.posVersion = value;
        }

        /**
         * Obtiene el valor de la propiedad signature.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSignature() {
            return signature;
        }

        /**
         * Define el valor de la propiedad signature.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSignature(String value) {
            this.signature = value;
        }

        /**
         * Obtiene el valor de la propiedad mid.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMID() {
            return mid;
        }

        /**
         * Define el valor de la propiedad mid.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMID(String value) {
            this.mid = value;
        }

    }

}
