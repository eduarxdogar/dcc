package com.credibanco.dcc.dtos;

import javax.validation.constraints.NotNull;

public class Input {
	
	
	private String ClerkID;
	private String TillID;
	private String TransactionType;
	private String POSVersion;
	private String SubGroupID;
	private String PartnerID;
	private String PreReceipt;
	private String Disclaimer;
	private String RequestScope;
	private String CurrencyCode;
	private String Serial;
	private String Version;
	private String Signature;
	private String MsgDateTime;
	private String CountryCode;
	private String BankID;
	
	@NotNull
	private String Amount;
	
	@NotNull
	private String MID;
	
	@NotNull
	private String TID;
	
	private String EntryType;
	
	@NotNull
	private String PAN;
	
	@NotNull
	private String merchantname;

	public String getClerkID() {
		return ClerkID;
	}

	public void setClerkID(String ClerkID) {
		this.ClerkID = ClerkID;
	}

	public String getTillID() {
		return TillID;
	}

	public void setTillID(String TillID) {
		this.TillID = TillID;
	}

	public String getTransactionType() {
		return TransactionType;
	}

	public void setTransactionType(String TransactionType) {
		this.TransactionType = TransactionType;
	}

	public String getPOSVersion() {
		return POSVersion;
	}

	public void setPOSVersion(String POSVersion) {
		this.POSVersion = POSVersion;
	}

	public String getSubGroupID() {
		return SubGroupID;
	}

	public void setSubGroupID(String SubGroupID) {
		this.SubGroupID = SubGroupID;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String Amount) {
		this.Amount = Amount;
	}

	public String getPartnerID() {
		return PartnerID;
	}

	public void setPartnerID(String PartnerID) {
		this.PartnerID = PartnerID;
	}

	public String getMID() {
		return MID;
	}

	public void setMID(String MID) {
		this.MID = MID;
	}

	public String getPreReceipt() {
		return PreReceipt;
	}

	public void setPreReceipt(String PreReceipt) {
		this.PreReceipt = PreReceipt;
	}

	public String getDisclaimer() {
		return Disclaimer;
	}

	public void setDisclaimer(String Disclaimer) {
		this.Disclaimer = Disclaimer;
	}

	public String getRequestScope() {
		return RequestScope;
	}

	public void setRequestScope(String RequestScope) {
		this.RequestScope = RequestScope;
	}

	public String getTID() {
		return TID;
	}

	public void setTID(String TID) {
		this.TID = TID;
	}

	public String getCurrencyCode() {
		return CurrencyCode;
	}

	public void setCurrencyCode(String CurrencyCode) {
		this.CurrencyCode = CurrencyCode;
	}

	public String getSerial() {
		return Serial;
	}

	public void setSerial(String Serial) {
		this.Serial = Serial;
	}

	public String getEntryType() {
		return EntryType;
	}

	public void setEntryType(String EntryType) {
		this.EntryType = EntryType;
	}

	public String getMerchantName() {
		return merchantname;
	}

	public void setMerchantName(String merchantname) {
		this.merchantname = merchantname;
	}

	public String getVersion() {
		return Version;
	}

	public void setVersion(String Version) {
		this.Version = Version;
	}

	public String getSignature() {
		return Signature;
	}

	public void setSignature(String Signature) {
		this.Signature = Signature;
	}

	public String getMsgDateTime() {
		return MsgDateTime;
	}

	public void setMsgDateTime(String MsgDateTime) {
		this.MsgDateTime = MsgDateTime;
	}

	public String getCountryCode() {
		return CountryCode;
	}

	public void setCountryCode(String CountryCode) {
		this.CountryCode = CountryCode;
	}

	public String getPAN() {
		return PAN;
	}

	public void setPAN(String PAN) {
		this.PAN = PAN;
	}

	public String getBankID() {
		return BankID;
	}

	public void setBankID(String BankID) {
		this.BankID = BankID;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Input [");
		if (ClerkID != null) {
			builder.append("ClerkID=");
			builder.append(ClerkID);
			builder.append(", ");
		}
		if (TillID != null) {
			builder.append("TillID=");
			builder.append(TillID);
			builder.append(", ");
		}
		if (TransactionType != null) {
			builder.append("TransactionType=");
			builder.append(TransactionType);
			builder.append(", ");
		}
		if (POSVersion != null) {
			builder.append("POSVersion=");
			builder.append(POSVersion);
			builder.append(", ");
		}
		if (SubGroupID != null) {
			builder.append("SubGroupID=");
			builder.append(SubGroupID);
			builder.append(", ");
		}
		if (PartnerID != null) {
			builder.append("PartnerID=");
			builder.append(PartnerID);
			builder.append(", ");
		}
		if (PreReceipt != null) {
			builder.append("PreReceipt=");
			builder.append(PreReceipt);
			builder.append(", ");
		}
		if (Disclaimer != null) {
			builder.append("Disclaimer=");
			builder.append(Disclaimer);
			builder.append(", ");
		}
		if (RequestScope != null) {
			builder.append("RequestScope=");
			builder.append(RequestScope);
			builder.append(", ");
		}
		if (CurrencyCode != null) {
			builder.append("CurrencyCode=");
			builder.append(CurrencyCode);
			builder.append(", ");
		}
		if (Serial != null) {
			builder.append("Serial=");
			builder.append(Serial);
			builder.append(", ");
		}
		if (Version != null) {
			builder.append("Version=");
			builder.append(Version);
			builder.append(", ");
		}
		if (Signature != null) {
			builder.append("Signature=");
			builder.append(Signature);
			builder.append(", ");
		}
		if (MsgDateTime != null) {
			builder.append("MsgDateTime=");
			builder.append(MsgDateTime);
			builder.append(", ");
		}
		if (CountryCode != null) {
			builder.append("CountryCode=");
			builder.append(CountryCode);
			builder.append(", ");
		}
		if (BankID != null) {
			builder.append("BankID=");
			builder.append(BankID);
			builder.append(", ");
		}
		if (Amount != null) {
			builder.append("Amount=");
			builder.append(Amount);
			builder.append(", ");
		}
		if (MID != null) {
			builder.append("MID=");
			builder.append(MID);
			builder.append(", ");
		}
		if (TID != null) {
			builder.append("TID=");
			builder.append(TID);
			builder.append(", ");
		}
		if (EntryType != null) {
			builder.append("EntryType=");
			builder.append(EntryType);
			builder.append(", ");
		}
		if (PAN != null) {
			builder.append("PAN=");
			builder.append(PAN);
			builder.append(", ");
		}
		if (merchantname != null) {
			builder.append("merchantname=");
			builder.append(merchantname);
		}
		builder.append("]");
		return builder.toString();
	}


}