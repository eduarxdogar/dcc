package com.credibanco.dcc.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import com.credibanco.dcc.planetWs.soap.client.PlanetDccClient;

@Configuration
public class DccConfig {

	@Autowired
	private Environment env;

	private static final String PACKAGE_DTO= "com.credibanco.dcc.planetWs.dto";
	
	@Bean
	public PlanetDccClient eaiTerminalClient() {
		System.out.println(env.getProperty("information.terminal.ath.ws.url"));
		Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
		// this package must match the package in the <generatePackage> specified in
		// pom.xml
		marshaller.setContextPath(PACKAGE_DTO);

		PlanetDccClient client = new PlanetDccClient();
		
		client.setDefaultUri(env.getProperty("information.terminal.ath.ws.url"));
		client.setMarshaller(marshaller);
		client.setUnmarshaller(marshaller);
		return client;
	}


}
