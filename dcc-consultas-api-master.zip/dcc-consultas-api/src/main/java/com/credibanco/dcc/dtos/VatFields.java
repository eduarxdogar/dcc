package com.credibanco.dcc.dtos;

import javax.xml.bind.annotation.XmlElement;

public class VatFields
{
	
    private String VatAmount;

	
    private String ToposAmount;

	
    private String AdminFee;

	
    private String VatEligibleVat;

	
    private String PriceExclVat;

	
    private String RefundAmount;

	
    private String PriceInclVat;

	
    private String NumberOfInvoices;

    @XmlElement(name = "VatAmount")
    public String getVatAmount ()
    {
        return VatAmount;
    }

    public void setVatAmount (String VatAmount)
    {
        this.VatAmount = VatAmount;
    }

    @XmlElement(name = "ToposAmount")
    public String getToposAmount ()
    {
        return ToposAmount;
    }

    public void setToposAmount (String ToposAmount)
    {
        this.ToposAmount = ToposAmount;
    }

    @XmlElement(name = "AdminFee")
    public String getAdminFee ()
    {
        return AdminFee;
    }

    public void setAdminFee (String AdminFee)
    {
        this.AdminFee = AdminFee;
    }

    @XmlElement(name = "VatEligibleVat")
    public String getVatEligibleVat ()
    {
        return VatEligibleVat;
    }

    public void setVatEligibleVat (String VatEligibleVat)
    {
        this.VatEligibleVat = VatEligibleVat;
    }

    @XmlElement(name = "PriceExclVat")
    public String getPriceExclVat ()
    {
        return PriceExclVat;
    }

    public void setPriceExclVat (String PriceExclVat)
    {
        this.PriceExclVat = PriceExclVat;
    }

    @XmlElement(name = "RefundAmount")
    public String getRefundAmount ()
    {
        return RefundAmount;
    }

    public void setRefundAmount (String RefundAmount)
    {
        this.RefundAmount = RefundAmount;
    }

    @XmlElement(name = "PriceInclVat")
    public String getPriceInclVat ()
    {
        return PriceInclVat;
    }

    public void setPriceInclVat (String PriceInclVat)
    {
        this.PriceInclVat = PriceInclVat;
    }

    @XmlElement(name = "NumberOfInvoices")
    public String getNumberOfInvoices ()
    {
        return NumberOfInvoices;
    }

    public void setNumberOfInvoices (String NumberOfInvoices)
    {
        this.NumberOfInvoices = NumberOfInvoices;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [VatAmount = "+VatAmount+", ToposAmount = "+ToposAmount+", AdminFee = "+AdminFee+", VatEligibleVat = "+VatEligibleVat+", PriceExclVat = "+PriceExclVat+", RefundAmount = "+RefundAmount+", PriceInclVat = "+PriceInclVat+", NumberOfInvoices = "+NumberOfInvoices+"]";
    }
}
