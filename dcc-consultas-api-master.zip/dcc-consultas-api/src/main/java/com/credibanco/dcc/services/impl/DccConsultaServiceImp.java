package com.credibanco.dcc.services.impl;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.credibanco.dcc.dtos.DccFields;
import com.credibanco.dcc.dtos.FdvoEligibilityResponse;
import com.credibanco.dcc.dtos.Input;
import com.credibanco.dcc.dtos.Response;
import com.credibanco.dcc.planetWs.dto.VatDccRequest;
import com.credibanco.dcc.planetWs.dto.VatDccRequestResponse;
import com.credibanco.dcc.planetWs.soap.client.PlanetDccClient;
import com.credibanco.dcc.services.DccConsultaService;
import com.credibanco.dcc.services.ITerminalConsultaService;
import com.credibanco.dcc.utils.RequestProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class DccConsultaServiceImp implements DccConsultaService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DccConsultaServiceImp.class);

	@Autowired
	RequestProperties requestProperties;
	
	ObjectMapper mapper = new ObjectMapper();

	@Value("${dcc.validateTerminal}")
	private Boolean validateTerminal;
	
	@Autowired
	private PlanetDccClient iathservice;
	
	@Autowired
	private ITerminalConsultaService terminalConsultaService;
	
	@Override
	public ResponseEntity<Response> exposePlanet(Input input) throws JsonProcessingException {
	
		LOGGER.info("Request start: input {}", input);
		if(validateTerminal && !terminalConsultaService.isTerminalDCC(input.getTID())) {
			Response response = new Response("ERROR: Terminal no activa para dcc" , new FdvoEligibilityResponse());
			return new ResponseEntity<>(response, HttpStatus.CONFLICT);
		}

		Input dataInputRequest = defineValuesToRequest(input);
		String concatenation = generateConcatenation(dataInputRequest);
		String SHA1 =  buildSHA (concatenation);
		String inputRequest = buildBody(dataInputRequest, SHA1);
	
		LOGGER.debug("Request planet: {}", inputRequest);
		VatDccRequest planetRequest = new VatDccRequest();
		planetRequest.setXMLString(inputRequest);
		
		VatDccRequestResponse responsePlanet = iathservice.sendToPlanet(planetRequest);
		LOGGER.debug("Response planet: {}", responsePlanet);
		
		String x = responsePlanet.getVatDccRequestResult().replace(
				"<?xml version=\"1.0\" encoding=\"utf-8\"?><FdvoEligibilityResponse xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://FdvoWebService.fintrax.com/FdvoSchema.xsd\">",
				"<FdvoEligibilityResponse>");
		try {
			Unmarshaller jaxbUnmarshaller = JAXBContext.newInstance(FdvoEligibilityResponse.class).createUnmarshaller();
			
			LOGGER.debug("Final response: {}", x);
			FdvoEligibilityResponse fdvoEligibilityResponse = (FdvoEligibilityResponse) jaxbUnmarshaller.unmarshal(new StringReader(x));

			DccFields dccFields = fdvoEligibilityResponse.getDccFields();

			dccFields.setDCCAmount("" + Double.valueOf(dccFields.getDCCAmount()) / 100.0);
			fdvoEligibilityResponse.setDccFields(dccFields);
			
			LOGGER.info("Request end: response {}", fdvoEligibilityResponse);
			return new ResponseEntity<>(new Response("OK", fdvoEligibilityResponse), HttpStatus.OK);
		} catch (JAXBException e) {
			LOGGER.error("Error exposePlanet(): {}", e.getMessage()); 
			Response responseError = new Response("ERROR: " + e.getMessage(), new FdvoEligibilityResponse());
			LOGGER.info("Request end: response {}", responseError);
			return new ResponseEntity<>(responseError, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	private Input defineValuesToRequest(Input input) {

		LOGGER.debug("Data input: {}", input);
		input.setVersion(input.getVersion() != null ? input.getVersion() : requestProperties.getVersion()); 
		input.setPartnerID(input.getPartnerID() != null ? input.getPartnerID() : requestProperties.getPartnerId());
		input.setSubGroupID(input.getSubGroupID() != null ? input.getSubGroupID() : requestProperties.getSubGroupId());
		input.setSerial(input.getSerial() != null ? input.getSerial() : requestProperties.getSerial());
		input.setRequestScope(input.getRequestScope() != null ? input.getRequestScope() : requestProperties.getScope());
		input.setCountryCode(input.getCountryCode() != null ? input.getCountryCode() : requestProperties.getCodeCountry());
		input.setCurrencyCode(input.getCurrencyCode() != null ? input.getCurrencyCode() : requestProperties.getCodeCurrency());
		input.setMsgDateTime(input.getMsgDateTime() != null ? input.getMsgDateTime() : requestProperties.getDateTime());
		input.setPOSVersion(input.getPOSVersion() != null ? input.getPOSVersion() : requestProperties.getVersionPos());
		input.setClerkID(input.getClerkID() != null ? input.getClerkID() : requestProperties.getClearkId());
		input.setTillID(input.getTillID() != null ? input.getTillID() : requestProperties.getTillId());
		input.setEntryType(input.getEntryType() != null ? input.getEntryType() : requestProperties.getTypeEntry());
		input.setTransactionType(input.getTransactionType() != null ? input.getTransactionType() : requestProperties.getTypeTransaction());
		input.setBankID(input.getBankID() != null ? input.getBankID() : requestProperties.getBankId());
		input.setPreReceipt(input.getPreReceipt() != null ? input.getPreReceipt() : requestProperties.getReceipt());
		input.setDisclaimer(input.getDisclaimer() != null ? input.getDisclaimer() : requestProperties.getDisclaimer());

		LOGGER.debug("Data input before modified: {}", input);
		return input;
	}

	private String buildBody(Input dataInputRequest, String signatureSHA) {
		StringBuilder requestStringBuilder = new StringBuilder();
		requestStringBuilder.append(
				"<FdvoEligibilityRequest xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://FdvoWebService.fintrax.com/FdvoSchema.xsd\">");
		requestStringBuilder.append("<MandatoryFields>");
		requestStringBuilder.append("<Version>" + dataInputRequest.getVersion() + "</Version>");
		requestStringBuilder.append("<PartnerID>" + dataInputRequest.getPartnerID() + "</PartnerID>");
		requestStringBuilder.append("<SubGroupID>" + dataInputRequest.getSubGroupID() + "</SubGroupID>");
		requestStringBuilder.append("<TID>" + dataInputRequest.getTID() + "</TID>");
		requestStringBuilder.append("<MerchantName>" + dataInputRequest.getMerchantName() + "</MerchantName>");
		requestStringBuilder.append("<Serial>" + dataInputRequest.getSerial() + "</Serial>");
		requestStringBuilder.append("<RequestScope>" + dataInputRequest.getRequestScope() + "</RequestScope>");
		requestStringBuilder.append("<CountryCode>" + dataInputRequest.getCountryCode() + "</CountryCode>");
		requestStringBuilder.append("<CurrencyCode>" + dataInputRequest.getCurrencyCode() + "</CurrencyCode>");
		requestStringBuilder.append("<Amount>" + Long.valueOf(dataInputRequest.getAmount()) * 100 + "</Amount>");
		requestStringBuilder.append("<MsgDateTime>" + dataInputRequest.getMsgDateTime() + "</MsgDateTime>");
		requestStringBuilder.append("<POSVersion>" + dataInputRequest.getPOSVersion() + "</POSVersion>");
		requestStringBuilder.append("<Signature>" + signatureSHA + "</Signature>");
		requestStringBuilder.append("<ClerkID>" + dataInputRequest.getClerkID() + "</ClerkID>");
		requestStringBuilder.append("<TillID>" + dataInputRequest.getTillID() + "</TillID>");
		requestStringBuilder.append("</MandatoryFields>");
		requestStringBuilder.append("<DCCFields>");
		requestStringBuilder.append("<MID>" + dataInputRequest.getMID() + "</MID>");
		requestStringBuilder.append("<PAN>" + dataInputRequest.getPAN() + "</PAN>");
		requestStringBuilder.append("<EntryType>" + dataInputRequest.getEntryType() + "</EntryType>");
		requestStringBuilder.append("<TransactionType>" + dataInputRequest.getTransactionType() + "</TransactionType>");
		requestStringBuilder.append("<BankID>" + dataInputRequest.getBankID() + "</BankID>");
		requestStringBuilder.append("<PreReceipt>" + dataInputRequest.getPreReceipt() + "</PreReceipt>");
		requestStringBuilder.append("<Disclaimer>" + dataInputRequest.getDisclaimer() + "</Disclaimer>");
		requestStringBuilder.append("</DCCFields>");
		requestStringBuilder.append("</FdvoEligibilityRequest>");
		return requestStringBuilder.toString();
	}

	private String generateConcatenation(Input dataInputRequest){
		String keyGUI = requestProperties.getSignatureKey();
		String concatenation = "";

		concatenation = dataInputRequest.getPartnerID() + dataInputRequest.getTID() + 
		dataInputRequest.getMsgDateTime() + keyGUI;

		return concatenation;
	}
	
	private String buildSHA (String concatenation){
		String sha1 = "";
		sha1 = org.apache.commons.codec.digest.DigestUtils.sha1Hex( concatenation );
		return sha1;
	}
	
	

	
	
	



}