package com.credibanco.dcc.dtos; 
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty; 

@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseTerminalDCC{
	@JsonProperty("serviciosTerminal")
    public List<ServiciosTerminal> serviciosTerminal;
	
	@JsonProperty("numeroTerminal")
    public String numeroTerminal;
	
	@JsonProperty("error")
    public Object error;

	public List<ServiciosTerminal> getServiciosTerminal() {
		return serviciosTerminal;
	}

	public void setServiciosTerminal(List<ServiciosTerminal> serviciosTerminal) {
		this.serviciosTerminal = serviciosTerminal;
	}

	public String getNumeroTerminal() {
		return numeroTerminal;
	}

	public void setNumeroTerminal(String numeroTerminal) {
		this.numeroTerminal = numeroTerminal;
	}

	public Object getError() {
		return error;
	}

	public void setError(Object error) {
		this.error = error;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseTerminalDCC [");
		if (serviciosTerminal != null) {
			builder.append("serviciosTerminal=");
			builder.append(serviciosTerminal);
			builder.append(", ");
		}
		if (numeroTerminal != null) {
			builder.append("numeroTerminal=");
			builder.append(numeroTerminal);
			builder.append(", ");
		}
		if (error != null) {
			builder.append("error=");
			builder.append(error);
		}
		builder.append("]");
		return builder.toString();
	}
	
	
}
