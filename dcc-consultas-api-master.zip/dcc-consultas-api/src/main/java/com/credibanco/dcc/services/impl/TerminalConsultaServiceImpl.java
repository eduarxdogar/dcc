package com.credibanco.dcc.services.impl;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.credibanco.clients.CyTRestClient;
import com.credibanco.dcc.dtos.RequestTerminalDCC;
import com.credibanco.dcc.dtos.ResponseTerminalDCC;
import com.credibanco.dcc.dtos.ServiciosTerminal;
import com.credibanco.dcc.services.ITerminalConsultaService;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class TerminalConsultaServiceImpl implements ITerminalConsultaService {
	
	private final Logger LOG = LoggerFactory.getLogger(TerminalConsultaServiceImpl.class);
	
	@Autowired
	private CyTRestClient cytRestClient;
	
	@Value("${dcc.portafolio.terminal}")
	private String portafolioTerminal;
	
	@Value("${dcc.visa}")
	private String visaDCC;
	
	ObjectMapper mapper = new ObjectMapper();

	@Override
	public boolean isTerminalDCC(String terminalID) {
		
		List<String> serviciosTerminal = new ArrayList<String>();
		serviciosTerminal.add(portafolioTerminal);
		RequestTerminalDCC requestTerminalDCC = new RequestTerminalDCC(terminalID, serviciosTerminal);
		
		try {
			LOG.debug("Get terminal info from responseTerminalDCC from terminal: {}", terminalID);
			Object responseTerminaldcc = cytRestClient.requestTerminalDCC(requestTerminalDCC);
			ResponseTerminalDCC finalResult = mapper.convertValue(responseTerminaldcc, ResponseTerminalDCC.class);
			LOG.debug("Method responseTerminalDCC: " + finalResult.toString());
			List<ServiciosTerminal> serviciosTerminalResponse = finalResult.getServiciosTerminal();
			LOG.debug("Terminal services: " + serviciosTerminalResponse.toString());
			LOG.debug("Check Dcc code {} in services: ", visaDCC);
			if(serviciosTerminalResponse != null) {
				for(ServiciosTerminal st : serviciosTerminalResponse) {		
					if(visaDCC.compareTo(st.getValue()) == 0) {
						if(st.isAplica()) {
							LOG.debug("Terminal is valid for DCC service...");
							return true;
						}
					}
				}
			}		
		} catch (KeyManagementException | KeyStoreException | NoSuchAlgorithmException e1) {
			LOG.error("Error isTerminalDCC: {}" , e1.getMessage());
		}
		
		return false;
	}

}
