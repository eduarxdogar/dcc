package com.credibanco.dcc.utils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class RequestProperties {

	
	@Value("${dcc.request.signature}")
	private String signature;

	@Value("${dcc.request.version}")
	private String version;

	@Value("${dcc.request.partner-id}")
	private String partnerId;

	@Value("${dcc.request.sub-group-id}")
	private String subGroupId;

	@Value("${dcc.request.serial}")
	private String serial;

	@Value("${dcc.request.scope}")
	private String scope;

	@Value("${dcc.request.code.country}")
	private String codeCountry;

	@Value("${dcc.request.code.currency}")
	private String codeCurrency;

	@Value("${dcc.request.date-time}")
	private String dateTime;

	@Value("${dcc.request.version.pos}")
	private String versionPos;

	@Value("${dcc.request.cleark-id}")
	private String clearkId;

	@Value("${dcc.request.till-id}")
	private String tillId;

	@Value("${dcc.request.type.entry}")
	private String typeEntry;

	@Value("${dcc.request.type.transaction}")
	private String typeTransaction;

	@Value("${dcc.request.bank-id}")
	private String bankId;

	@Value("${dcc.request.receipt}")
	private String receipt;

	@Value("${dcc.request.disclaimer}")
	private String disclaimer;

	@Value("${dcc.request.signatureKey}")
	private String signatureKey;
	
	public String getSignature() {
		return signature;
	}

	public String getVersion() {
		return version;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public String getSubGroupId() {
		return subGroupId;
	}

	public String getSerial() {
		return serial;
	}

	public String getScope() {
		return scope;
	}

	public String getCodeCountry() {
		return codeCountry;
	}

	public String getCodeCurrency() {
		return codeCurrency;
	}

	public String getDateTime() {
		return dateTime;
	}

	public String getVersionPos() {
		return versionPos;
	}

	public String getClearkId() {
		return clearkId;
	}

	public String getTillId() {
		return tillId;
	}

	public String getTypeEntry() {
		return typeEntry;
	}

	public String getTypeTransaction() {
		return typeTransaction;
	}

	public String getBankId() {
		return bankId;
	}

	public String getReceipt() {
		return receipt;
	}

	public String getDisclaimer() {
		return disclaimer;
	}

	public String getSignatureKey() {
		return signatureKey;
	}


}
