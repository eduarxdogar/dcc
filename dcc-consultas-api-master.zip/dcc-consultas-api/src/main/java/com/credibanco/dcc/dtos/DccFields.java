package com.credibanco.dcc.dtos;

import javax.xml.bind.annotation.XmlElement;

public class DccFields
{
	
    private String DCCAmount;

	
    private String PreDisclaimer;

	
    private String ExchangeRate;

	
    private String Choice;

	
    private String RatesDateEffective;

	
    private String LocalAmount;

	
    private String WholeSaleRate;

	
    private String MID;

	
    private String Markup;

	
    private String RatesDateTime;

	
    private String RatesSource;

	
    private String DCCExponent;

	
    private String PostDisclaimer;

    @XmlElement(name = "DCCAmount")
    public String getDCCAmount ()
    {
        return DCCAmount;
    }

    public void setDCCAmount (String DCCAmount)
    {
        this.DCCAmount = DCCAmount;
    }

    @XmlElement(name = "PreDisclaimer")
    public String getPreDisclaimer ()
    {
        return PreDisclaimer;
    }

    public void setPreDisclaimer (String PreDisclaimer)
    {
        this.PreDisclaimer = PreDisclaimer;
    }

    @XmlElement(name = "ExchangeRate")
    public String getExchangeRate ()
    {
        return ExchangeRate;
    }

    public void setExchangeRate (String ExchangeRate)
    {
        this.ExchangeRate = ExchangeRate;
    }

    @XmlElement(name = "Choice")
    public String getChoice ()
    {
        return Choice;
    }

    public void setChoice (String Choice)
    {
        this.Choice = Choice;
    }

    @XmlElement(name = "RatesDateEffective")
    public String getRatesDateEffective ()
    {
        return RatesDateEffective;
    }

    public void setRatesDateEffective (String RatesDateEffective)
    {
        this.RatesDateEffective = RatesDateEffective;
    }

    @XmlElement(name = "LocalAmount")
    public String getLocalAmount ()
    {
        return LocalAmount;
    }

    public void setLocalAmount (String LocalAmount)
    {
        this.LocalAmount = LocalAmount;
    }

    @XmlElement(name = "WholeSaleRate")
    public String getWholeSaleRate ()
    {
        return WholeSaleRate;
    }

    public void setWholeSaleRate (String WholeSaleRate)
    {
        this.WholeSaleRate = WholeSaleRate;
    }

    @XmlElement(name = "MID")
    public String getMID ()
    {
        return MID;
    }

    public void setMID (String MID)
    {
        this.MID = MID;
    }

    @XmlElement(name = "Markup")
    public String getMarkup ()
    {
        return Markup;
    }

    public void setMarkup (String Markup)
    {
        this.Markup = Markup;
    }

    @XmlElement(name = "RatesDateTime")
    public String getRatesDateTime ()
    {
        return RatesDateTime;
    }

    public void setRatesDateTime (String RatesDateTime)
    {
        this.RatesDateTime = RatesDateTime;
    }

    @XmlElement(name = "RatesSource")
    public String getRatesSource ()
    {
        return RatesSource;
    }

    public void setRatesSource (String RatesSource)
    {
        this.RatesSource = RatesSource;
    }

    @XmlElement(name = "DCCExponent")
    public String getDCCExponent ()
    {
        return DCCExponent;
    }

    public void setDCCExponent (String DCCExponent)
    {
        this.DCCExponent = DCCExponent;
    }

    @XmlElement(name = "PostDisclaimer")
    public String getPostDisclaimer ()
    {
        return PostDisclaimer;
    }

    public void setPostDisclaimer (String PostDisclaimer)
    {
        this.PostDisclaimer = PostDisclaimer;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [DCCAmount = "+DCCAmount+", PreDisclaimer = "+PreDisclaimer+", ExchangeRate = "+ExchangeRate+", Choice = "+Choice+", RatesDateEffective = "+RatesDateEffective+", LocalAmount = "+LocalAmount+", WholeSaleRate = "+WholeSaleRate+", MID = "+MID+", Markup = "+Markup+", RatesDateTime = "+RatesDateTime+", RatesSource = "+RatesSource+", DCCExponent = "+DCCExponent+", PostDisclaimer = "+PostDisclaimer+"]";
    }
}