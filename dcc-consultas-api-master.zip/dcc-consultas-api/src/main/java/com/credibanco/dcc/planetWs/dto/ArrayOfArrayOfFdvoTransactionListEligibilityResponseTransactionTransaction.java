//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Transaction" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;attribute name="CustomerReference" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *                 &lt;attribute name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="Currency" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="Country" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="CardSchema" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema", propOrder = {
    "transaction"
})
public class ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction {

    @XmlElement(name = "Transaction")
    protected List<ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction> transaction;

    /**
     * Gets the value of the transaction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transaction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransaction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction }
     * 
     * 
     */
    public List<ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction> getTransaction() {
        if (transaction == null) {
            transaction = new ArrayList<ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction>();
        }
        return this.transaction;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;attribute name="CustomerReference" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
     *       &lt;attribute name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="Currency" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="Country" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="CardSchema" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Transaction {

        @XmlAttribute(name = "CustomerReference")
        protected Integer customerReference;
        @XmlAttribute(name = "PAN")
        protected String pan;
        @XmlAttribute(name = "Currency")
        protected String currency;
        @XmlAttribute(name = "Country")
        protected String country;
        @XmlAttribute(name = "CardSchema")
        protected String cardSchema;

        /**
         * Obtiene el valor de la propiedad customerReference.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getCustomerReference() {
            return customerReference;
        }

        /**
         * Define el valor de la propiedad customerReference.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setCustomerReference(Integer value) {
            this.customerReference = value;
        }

        /**
         * Obtiene el valor de la propiedad pan.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPAN() {
            return pan;
        }

        /**
         * Define el valor de la propiedad pan.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPAN(String value) {
            this.pan = value;
        }

        /**
         * Obtiene el valor de la propiedad currency.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCurrency() {
            return currency;
        }

        /**
         * Define el valor de la propiedad currency.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCurrency(String value) {
            this.currency = value;
        }

        /**
         * Obtiene el valor de la propiedad country.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountry() {
            return country;
        }

        /**
         * Define el valor de la propiedad country.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountry(String value) {
            this.country = value;
        }

        /**
         * Obtiene el valor de la propiedad cardSchema.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCardSchema() {
            return cardSchema;
        }

        /**
         * Define el valor de la propiedad cardSchema.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCardSchema(String value) {
            this.cardSchema = value;
        }

    }

}
