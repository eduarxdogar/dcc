//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="MainFields" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="SubGroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="TID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="CrtVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="POSVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Result"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;enumeration value="0"/&gt;
 *                         &lt;enumeration value="1"/&gt;
 *                         &lt;enumeration value="2"/&gt;
 *                         &lt;enumeration value="3"/&gt;
 *                         &lt;enumeration value="4"/&gt;
 *                         &lt;enumeration value="5"/&gt;
 *                         &lt;enumeration value="7"/&gt;
 *                         &lt;enumeration value="8"/&gt;
 *                         &lt;enumeration value="9"/&gt;
 *                         &lt;enumeration value="10"/&gt;
 *                         &lt;enumeration value="103"/&gt;
 *                         &lt;enumeration value="143"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Transactions" type="{http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema}ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "mainFields",
    "transactions"
})
@XmlRootElement(name = "FdvoTransactionListEligibilityResponse", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
public class FdvoTransactionListEligibilityResponse {

    @XmlElement(name = "MainFields", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
    protected FdvoTransactionListEligibilityResponse.MainFields mainFields;
    @XmlElement(name = "Transactions", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
    protected ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction transactions;

    /**
     * Obtiene el valor de la propiedad mainFields.
     * 
     * @return
     *     possible object is
     *     {@link FdvoTransactionListEligibilityResponse.MainFields }
     *     
     */
    public FdvoTransactionListEligibilityResponse.MainFields getMainFields() {
        return mainFields;
    }

    /**
     * Define el valor de la propiedad mainFields.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoTransactionListEligibilityResponse.MainFields }
     *     
     */
    public void setMainFields(FdvoTransactionListEligibilityResponse.MainFields value) {
        this.mainFields = value;
    }

    /**
     * Obtiene el valor de la propiedad transactions.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction }
     *     
     */
    public ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction getTransactions() {
        return transactions;
    }

    /**
     * Define el valor de la propiedad transactions.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction }
     *     
     */
    public void setTransactions(ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction value) {
        this.transactions = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="SubGroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="TID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="CrtVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="POSVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Result"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;enumeration value="0"/&gt;
     *               &lt;enumeration value="1"/&gt;
     *               &lt;enumeration value="2"/&gt;
     *               &lt;enumeration value="3"/&gt;
     *               &lt;enumeration value="4"/&gt;
     *               &lt;enumeration value="5"/&gt;
     *               &lt;enumeration value="7"/&gt;
     *               &lt;enumeration value="8"/&gt;
     *               &lt;enumeration value="9"/&gt;
     *               &lt;enumeration value="10"/&gt;
     *               &lt;enumeration value="103"/&gt;
     *               &lt;enumeration value="143"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "version",
        "partnerID",
        "subGroupID",
        "merchantName",
        "tid",
        "sessionID",
        "crtVersion",
        "msgDateTime",
        "posVersion",
        "result",
        "errorMessage",
        "signature",
        "mid"
    })
    public static class MainFields {

        @XmlElement(name = "Version", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String version;
        @XmlElement(name = "PartnerID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected int partnerID;
        @XmlElement(name = "SubGroupID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected int subGroupID;
        @XmlElement(name = "MerchantName", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String merchantName;
        @XmlElement(name = "TID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String tid;
        @XmlElement(name = "SessionID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected int sessionID;
        @XmlElement(name = "CrtVersion", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String crtVersion;
        @XmlElement(name = "MsgDateTime", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String msgDateTime;
        @XmlElement(name = "POSVersion", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String posVersion;
        @XmlElement(name = "Result", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema", required = true)
        protected String result;
        @XmlElement(name = "ErrorMessage", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String errorMessage;
        @XmlElement(name = "Signature", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String signature;
        @XmlElement(name = "MID", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema")
        protected String mid;

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersion(String value) {
            this.version = value;
        }

        /**
         * Obtiene el valor de la propiedad partnerID.
         * 
         */
        public int getPartnerID() {
            return partnerID;
        }

        /**
         * Define el valor de la propiedad partnerID.
         * 
         */
        public void setPartnerID(int value) {
            this.partnerID = value;
        }

        /**
         * Obtiene el valor de la propiedad subGroupID.
         * 
         */
        public int getSubGroupID() {
            return subGroupID;
        }

        /**
         * Define el valor de la propiedad subGroupID.
         * 
         */
        public void setSubGroupID(int value) {
            this.subGroupID = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMerchantName() {
            return merchantName;
        }

        /**
         * Define el valor de la propiedad merchantName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMerchantName(String value) {
            this.merchantName = value;
        }

        /**
         * Obtiene el valor de la propiedad tid.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTID() {
            return tid;
        }

        /**
         * Define el valor de la propiedad tid.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTID(String value) {
            this.tid = value;
        }

        /**
         * Obtiene el valor de la propiedad sessionID.
         * 
         */
        public int getSessionID() {
            return sessionID;
        }

        /**
         * Define el valor de la propiedad sessionID.
         * 
         */
        public void setSessionID(int value) {
            this.sessionID = value;
        }

        /**
         * Obtiene el valor de la propiedad crtVersion.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCrtVersion() {
            return crtVersion;
        }

        /**
         * Define el valor de la propiedad crtVersion.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCrtVersion(String value) {
            this.crtVersion = value;
        }

        /**
         * Obtiene el valor de la propiedad msgDateTime.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMsgDateTime() {
            return msgDateTime;
        }

        /**
         * Define el valor de la propiedad msgDateTime.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMsgDateTime(String value) {
            this.msgDateTime = value;
        }

        /**
         * Obtiene el valor de la propiedad posVersion.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPOSVersion() {
            return posVersion;
        }

        /**
         * Define el valor de la propiedad posVersion.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPOSVersion(String value) {
            this.posVersion = value;
        }

        /**
         * Obtiene el valor de la propiedad result.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getResult() {
            return result;
        }

        /**
         * Define el valor de la propiedad result.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setResult(String value) {
            this.result = value;
        }

        /**
         * Obtiene el valor de la propiedad errorMessage.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getErrorMessage() {
            return errorMessage;
        }

        /**
         * Define el valor de la propiedad errorMessage.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setErrorMessage(String value) {
            this.errorMessage = value;
        }

        /**
         * Obtiene el valor de la propiedad signature.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSignature() {
            return signature;
        }

        /**
         * Define el valor de la propiedad signature.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSignature(String value) {
            this.signature = value;
        }

        /**
         * Obtiene el valor de la propiedad mid.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMID() {
            return mid;
        }

        /**
         * Define el valor de la propiedad mid.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMID(String value) {
            this.mid = value;
        }

    }

}
