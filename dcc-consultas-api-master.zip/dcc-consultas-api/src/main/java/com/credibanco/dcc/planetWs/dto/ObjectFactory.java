//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.credibanco.dcc.planetWs.dto package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CurrencyConvertibilityEligibilityRequest_QNAME = new QName("http://FdvoWebService.fintrax.com/FdvoSchema", "CurrencyConvertibilityEligibilityRequest");
    private final static QName _CurrencyConvertibilityEligibilityResponse_QNAME = new QName("http://FdvoWebService.fintrax.com/FdvoSchema", "CurrencyConvertibilityEligibilityResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.credibanco.dcc.planetWs.dto
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link FdvoTransactionListEligibilityRequest }
     * 
     */
    public FdvoTransactionListEligibilityRequest createFdvoTransactionListEligibilityRequest() {
        return new FdvoTransactionListEligibilityRequest();
    }

    /**
     * Create an instance of {@link FdvoTransactionListEligibilityResponse }
     * 
     */
    public FdvoTransactionListEligibilityResponse createFdvoTransactionListEligibilityResponse() {
        return new FdvoTransactionListEligibilityResponse();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceRequest }
     * 
     */
    public FdvoRatesServiceRequest createFdvoRatesServiceRequest() {
        return new FdvoRatesServiceRequest();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceResponse }
     * 
     */
    public FdvoRatesServiceResponse createFdvoRatesServiceResponse() {
        return new FdvoRatesServiceResponse();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate }
     * 
     */
    public ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate createArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate() {
        return new ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode createArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard createArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode createArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard createArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard();
    }

    /**
     * Create an instance of {@link CurrencyConvertibilityEligibilityResponse }
     * 
     */
    public CurrencyConvertibilityEligibilityResponse createCurrencyConvertibilityEligibilityResponse() {
        return new CurrencyConvertibilityEligibilityResponse();
    }

    /**
     * Create an instance of {@link CurrencyConvertibilityEligibilityRequest }
     * 
     */
    public CurrencyConvertibilityEligibilityRequest createCurrencyConvertibilityEligibilityRequest() {
        return new CurrencyConvertibilityEligibilityRequest();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction }
     * 
     */
    public ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction createArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction() {
        return new ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction }
     * 
     */
    public ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction createArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction() {
        return new ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction();
    }

    /**
     * Create an instance of {@link VatDccRequest }
     * 
     */
    public VatDccRequest createVatDccRequest() {
        return new VatDccRequest();
    }

    /**
     * Create an instance of {@link VatDccRequestResponse }
     * 
     */
    public VatDccRequestResponse createVatDccRequestResponse() {
        return new VatDccRequestResponse();
    }

    /**
     * Create an instance of {@link VatDccConfirmation }
     * 
     */
    public VatDccConfirmation createVatDccConfirmation() {
        return new VatDccConfirmation();
    }

    /**
     * Create an instance of {@link VatDccConfirmationResponse }
     * 
     */
    public VatDccConfirmationResponse createVatDccConfirmationResponse() {
        return new VatDccConfirmationResponse();
    }

    /**
     * Create an instance of {@link FdvoTransactionListEligibilityRequest.MandatoryFields }
     * 
     */
    public FdvoTransactionListEligibilityRequest.MandatoryFields createFdvoTransactionListEligibilityRequestMandatoryFields() {
        return new FdvoTransactionListEligibilityRequest.MandatoryFields();
    }

    /**
     * Create an instance of {@link FdvoTransactionListEligibilityResponse.MainFields }
     * 
     */
    public FdvoTransactionListEligibilityResponse.MainFields createFdvoTransactionListEligibilityResponseMainFields() {
        return new FdvoTransactionListEligibilityResponse.MainFields();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceRequest.PartnerDetails }
     * 
     */
    public FdvoRatesServiceRequest.PartnerDetails createFdvoRatesServiceRequestPartnerDetails() {
        return new FdvoRatesServiceRequest.PartnerDetails();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceRequest.RatesDetails }
     * 
     */
    public FdvoRatesServiceRequest.RatesDetails createFdvoRatesServiceRequestRatesDetails() {
        return new FdvoRatesServiceRequest.RatesDetails();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceResponse.PartnerDetails }
     * 
     */
    public FdvoRatesServiceResponse.PartnerDetails createFdvoRatesServiceResponsePartnerDetails() {
        return new FdvoRatesServiceResponse.PartnerDetails();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceResponse.RatesDetails }
     * 
     */
    public FdvoRatesServiceResponse.RatesDetails createFdvoRatesServiceResponseRatesDetails() {
        return new FdvoRatesServiceResponse.RatesDetails();
    }

    /**
     * Create an instance of {@link FdvoRatesServiceResponse.ErrorNode }
     * 
     */
    public FdvoRatesServiceResponse.ErrorNode createFdvoRatesServiceResponseErrorNode() {
        return new FdvoRatesServiceResponse.ErrorNode();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate }
     * 
     */
    public ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate createArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRateRate() {
        return new ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate.Rate();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode.ErrorNode }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode.ErrorNode createArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNodeErrorNode() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode.ErrorNode();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card createArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCardCard() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode.ErrorNode }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode.ErrorNode createArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNodeErrorNode() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode.ErrorNode();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard.Card }
     * 
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard.Card createArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCardCard() {
        return new ArrayOfArrayOfCurrencyConvertibilityEligibilityRequestCardCard.Card();
    }

    /**
     * Create an instance of {@link CurrencyConvertibilityEligibilityResponse.Merchant }
     * 
     */
    public CurrencyConvertibilityEligibilityResponse.Merchant createCurrencyConvertibilityEligibilityResponseMerchant() {
        return new CurrencyConvertibilityEligibilityResponse.Merchant();
    }

    /**
     * Create an instance of {@link CurrencyConvertibilityEligibilityRequest.Merchant }
     * 
     */
    public CurrencyConvertibilityEligibilityRequest.Merchant createCurrencyConvertibilityEligibilityRequestMerchant() {
        return new CurrencyConvertibilityEligibilityRequest.Merchant();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction }
     * 
     */
    public ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction createArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransactionTransaction() {
        return new ArrayOfArrayOfFdvoTransactionListEligibilityResponseTransactionTransaction.Transaction();
    }

    /**
     * Create an instance of {@link ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction }
     * 
     */
    public ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction createArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransactionTransaction() {
        return new ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CurrencyConvertibilityEligibilityRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://FdvoWebService.fintrax.com/FdvoSchema", name = "CurrencyConvertibilityEligibilityRequest")
    public JAXBElement<CurrencyConvertibilityEligibilityRequest> createCurrencyConvertibilityEligibilityRequest(CurrencyConvertibilityEligibilityRequest value) {
        return new JAXBElement<CurrencyConvertibilityEligibilityRequest>(_CurrencyConvertibilityEligibilityRequest_QNAME, CurrencyConvertibilityEligibilityRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CurrencyConvertibilityEligibilityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://FdvoWebService.fintrax.com/FdvoSchema", name = "CurrencyConvertibilityEligibilityResponse")
    public JAXBElement<CurrencyConvertibilityEligibilityResponse> createCurrencyConvertibilityEligibilityResponse(CurrencyConvertibilityEligibilityResponse value) {
        return new JAXBElement<CurrencyConvertibilityEligibilityResponse>(_CurrencyConvertibilityEligibilityResponse_QNAME, CurrencyConvertibilityEligibilityResponse.class, null, value);
    }

}
