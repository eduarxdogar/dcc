package com.credibanco.dcc.planetWs.soap.client;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

import com.credibanco.dcc.planetWs.dto.VatDccRequest;
import com.credibanco.dcc.planetWs.dto.VatDccRequestResponse;

public class PlanetDccClient extends WebServiceGatewaySupport {

	public VatDccRequestResponse sendToPlanet(VatDccRequest request) {
		return (VatDccRequestResponse) getWebServiceTemplate().marshalSendAndReceive(request, new SoapActionCallback("http://FdvoWebService.fintrax.com/VatDccRequest"));
	}

}
