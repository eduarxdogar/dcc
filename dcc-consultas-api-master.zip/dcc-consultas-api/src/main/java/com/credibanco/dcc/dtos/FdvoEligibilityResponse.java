package com.credibanco.dcc.dtos;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="FdvoEligibilityResponse")
public class FdvoEligibilityResponse
{

    private DccFields DccFields;

    private MainFields MainFields;

    private VatFields VatFields;

    @XmlElement(name="DccFields")
    public DccFields getDccFields ()
    {
        return DccFields;
    }

    public void setDccFields (DccFields DccFields)
    {
        this.DccFields = DccFields;
    }

    @XmlElement(name="MainFields")
    public MainFields getMainFields ()
    {
        return MainFields;
    }

    public void setMainFields (MainFields MainFields)
    {
        this.MainFields = MainFields;
    }

    @XmlElement(name="VatFields")
    public VatFields getVatFields ()
    {
        return VatFields;
    }

    public void setVatFields (VatFields VatFields)
    {
        this.VatFields = VatFields;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [DccFields = "+DccFields+", MainFields = "+MainFields+", VatFields = "+VatFields+"]";
    }
}