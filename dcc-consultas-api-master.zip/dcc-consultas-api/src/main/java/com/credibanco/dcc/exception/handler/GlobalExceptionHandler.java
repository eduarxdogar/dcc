package com.credibanco.dcc.exception.handler;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.credibanco.dcc.dtos.ErrorDetails;

@ControllerAdvice
public class GlobalExceptionHandler{
	
	// Handle Global exception
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleGlobalException(Exception exception){
		return new ResponseEntity<>(new ErrorDetails(new Date(), "Internal Error", exception.getLocalizedMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
