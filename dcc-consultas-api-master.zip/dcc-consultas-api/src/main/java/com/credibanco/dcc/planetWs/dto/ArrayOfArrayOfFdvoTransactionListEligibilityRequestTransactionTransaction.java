//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Transaction" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;attribute name="CustomerReference" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *                 &lt;attribute name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *                 &lt;attribute name="Type" use="required"&gt;
 *                   &lt;simpleType&gt;
 *                     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                       &lt;enumeration value="0"/&gt;
 *                       &lt;enumeration value="1"/&gt;
 *                       &lt;enumeration value="2"/&gt;
 *                       &lt;enumeration value="3"/&gt;
 *                       &lt;enumeration value="4"/&gt;
 *                       &lt;enumeration value="5"/&gt;
 *                     &lt;/restriction&gt;
 *                   &lt;/simpleType&gt;
 *                 &lt;/attribute&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction", namespace = "http://FdvoWebService.fintrax.com/FdvoTransactionListEligibilitySchema", propOrder = {
    "transaction"
})
public class ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction {

    @XmlElement(name = "Transaction")
    protected List<ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction> transaction;

    /**
     * Gets the value of the transaction property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the transaction property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTransaction().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction }
     * 
     * 
     */
    public List<ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction> getTransaction() {
        if (transaction == null) {
            transaction = new ArrayList<ArrayOfArrayOfFdvoTransactionListEligibilityRequestTransactionTransaction.Transaction>();
        }
        return this.transaction;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;attribute name="CustomerReference" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
     *       &lt;attribute name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
     *       &lt;attribute name="Type" use="required"&gt;
     *         &lt;simpleType&gt;
     *           &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *             &lt;enumeration value="0"/&gt;
     *             &lt;enumeration value="1"/&gt;
     *             &lt;enumeration value="2"/&gt;
     *             &lt;enumeration value="3"/&gt;
     *             &lt;enumeration value="4"/&gt;
     *             &lt;enumeration value="5"/&gt;
     *           &lt;/restriction&gt;
     *         &lt;/simpleType&gt;
     *       &lt;/attribute&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "")
    public static class Transaction {

        @XmlAttribute(name = "CustomerReference")
        protected Integer customerReference;
        @XmlAttribute(name = "PAN")
        protected String pan;
        @XmlAttribute(name = "Type", required = true)
        protected String type;

        /**
         * Obtiene el valor de la propiedad customerReference.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getCustomerReference() {
            return customerReference;
        }

        /**
         * Define el valor de la propiedad customerReference.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setCustomerReference(Integer value) {
            this.customerReference = value;
        }

        /**
         * Obtiene el valor de la propiedad pan.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPAN() {
            return pan;
        }

        /**
         * Define el valor de la propiedad pan.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPAN(String value) {
            this.pan = value;
        }

        /**
         * Obtiene el valor de la propiedad type.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getType() {
            return type;
        }

        /**
         * Define el valor de la propiedad type.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setType(String value) {
            this.type = value;
        }

    }

}
