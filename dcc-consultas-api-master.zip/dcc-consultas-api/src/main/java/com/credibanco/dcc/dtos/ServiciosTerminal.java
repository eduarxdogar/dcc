package com.credibanco.dcc.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiciosTerminal{
	
	@JsonProperty("servicio")
    public String servicio;
	
	@JsonProperty("aplica")
    public boolean aplica;
	
	@JsonProperty("value")
    public String value;
	
	public String getServicio() {
		return servicio;
	}

	public void setServicio(String servicio) {
		this.servicio = servicio;
	}

	public boolean isAplica() {
		return aplica;
	}

	public void setAplica(boolean aplica) {
		this.aplica = aplica;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ServiciosTerminal [");
		if (servicio != null) {
			builder.append("servicio=");
			builder.append(servicio);
			builder.append(", ");
		}
		builder.append("aplica=");
		builder.append(aplica);
		builder.append(", ");
		if (value != null) {
			builder.append("value=");
			builder.append(value);
		}
		builder.append("]");
		return builder.toString();
	}
	
	
}
