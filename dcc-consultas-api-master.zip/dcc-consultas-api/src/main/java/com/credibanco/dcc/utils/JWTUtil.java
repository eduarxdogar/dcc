package com.credibanco.dcc.utils;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JWTUtil {
	
	private static final Logger LOG = LoggerFactory.getLogger(JWTUtil.class);
	
	@SuppressWarnings("unchecked")
	public static String getPreferredUsernameFromPayloadJWT(String token) throws Exception {
		String[] tokenSplit = token.split("\\.");
		Base64.Decoder decoder = Base64.getDecoder();
		String payload = new String(decoder.decode(tokenSplit[1]));
		Map<String, String> payloadMap;
		String preferredUsername = "";
		try {
			payloadMap = new ObjectMapper().readValue(payload, HashMap.class);
			preferredUsername = payloadMap.get("preferred_username");
		} catch (IOException e) {
			LOG.error("Error decode JWT: ", e);
			throw new Exception("Error decode JWT: ", e);
		}
		return preferredUsername;
	}

}
