package com.credibanco.dcc.dtos;

import javax.xml.bind.annotation.XmlElement;

public class MainFields
{
	
    private String VATEligibilityCode;

	
    private String POSVersion;

	
    private String DCCEligibilityCode;

	
    private String SubGroupID;

	
    private String PartnerID;

	
    private String TID;

	
    private String Result;

	
    private String LookupCurrencyCode;

	
    private String Serial;

	
    private String MerchantName;

	
    private String LookupCountryCode;

	
    private String Version;

	
    private String Signature;

	
    private String LookupCurrencyName;

	
    private String MsgDateTime;

	
    private String CrtVersion;

	
    private String SessionID;

    @XmlElement(name = "VATEligibilityCode")
    public String getVATEligibilityCode ()
    {
        return VATEligibilityCode;
    }

    public void setVATEligibilityCode (String VATEligibilityCode)
    {
        this.VATEligibilityCode = VATEligibilityCode;
    }

    @XmlElement(name = "POSVersion")
    public String getPOSVersion ()
    {
        return POSVersion;
    }

    public void setPOSVersion (String POSVersion)
    {
        this.POSVersion = POSVersion;
    }

    @XmlElement(name = "DCCEligibilityCode")
    public String getDCCEligibilityCode ()
    {
        return DCCEligibilityCode;
    }

    public void setDCCEligibilityCode (String DCCEligibilityCode)
    {
        this.DCCEligibilityCode = DCCEligibilityCode;
    }

    @XmlElement(name = "SubGroupID")
    public String getSubGroupID ()
    {
        return SubGroupID;
    }

    public void setSubGroupID (String SubGroupID)
    {
        this.SubGroupID = SubGroupID;
    }

    @XmlElement(name = "PartnerID")
    public String getPartnerID ()
    {
        return PartnerID;
    }

    public void setPartnerID (String PartnerID)
    {
        this.PartnerID = PartnerID;
    }

    @XmlElement(name = "TID")
    public String getTID ()
    {
        return TID;
    }

    public void setTID (String TID)
    {
        this.TID = TID;
    }

    @XmlElement(name = "Result")
    public String getResult ()
    {
        return Result;
    }

    public void setResult (String Result)
    {
        this.Result = Result;
    }

    @XmlElement(name = "LookupCurrencyCode")
    public String getLookupCurrencyCode ()
    {
        return LookupCurrencyCode;
    }

    public void setLookupCurrencyCode (String LookupCurrencyCode)
    {
        this.LookupCurrencyCode = LookupCurrencyCode;
    }

    @XmlElement(name = "Serial")
    public String getSerial ()
    {
        return Serial;
    }

    public void setSerial (String Serial)
    {
        this.Serial = Serial;
    }

    @XmlElement(name = "MerchantName")
    public String getMerchantName ()
    {
        return MerchantName;
    }

    public void setMerchantName (String MerchantName)
    {
        this.MerchantName = MerchantName;
    }

    @XmlElement(name = "LookupCountryCode")
    public String getLookupCountryCode ()
    {
        return LookupCountryCode;
    }

    public void setLookupCountryCode (String LookupCountryCode)
    {
        this.LookupCountryCode = LookupCountryCode;
    }

    @XmlElement(name = "Version")
    public String getVersion ()
    {
        return Version;
    }

    public void setVersion (String Version)
    {
        this.Version = Version;
    }

    @XmlElement(name = "Signature")
    public String getSignature ()
    {
        return Signature;
    }

    public void setSignature (String Signature)
    {
        this.Signature = Signature;
    }

    @XmlElement(name = "LookupCurrencyName")
    public String getLookupCurrencyName ()
    {
        return LookupCurrencyName;
    }

    public void setLookupCurrencyName (String LookupCurrencyName)
    {
        this.LookupCurrencyName = LookupCurrencyName;
    }

    @XmlElement(name = "MsgDateTime")
    public String getMsgDateTime ()
    {
        return MsgDateTime;
    }

    public void setMsgDateTime (String MsgDateTime)
    {
        this.MsgDateTime = MsgDateTime;
    }

    @XmlElement(name = "CrtVersion")
    public String getCrtVersion ()
    {
        return CrtVersion;
    }

    public void setCrtVersion (String CrtVersion)
    {
        this.CrtVersion = CrtVersion;
    }

    @XmlElement(name = "SessionID")
    public String getSessionID ()
    {
        return SessionID;
    }

    public void setSessionID (String SessionID)
    {
        this.SessionID = SessionID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [VATEligibilityCode = "+VATEligibilityCode+", POSVersion = "+POSVersion+", DCCEligibilityCode = "+DCCEligibilityCode+", SubGroupID = "+SubGroupID+", PartnerID = "+PartnerID+", TID = "+TID+", Result = "+Result+", LookupCurrencyCode = "+LookupCurrencyCode+", Serial = "+Serial+", MerchantName = "+MerchantName+", LookupCountryCode = "+LookupCountryCode+", Version = "+Version+", Signature = "+Signature+", LookupCurrencyName = "+LookupCurrencyName+", MsgDateTime = "+MsgDateTime+", CrtVersion = "+CrtVersion+", SessionID = "+SessionID+"]";
    }
}