package com.credibanco.dcc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.credibanco.dcc.dtos.Input;
import com.credibanco.dcc.services.DccConsultaService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
public class TerminalDccController{
	
	@Autowired
	DccConsultaService dccConsultaService;
	
	@PostMapping("/dcc")
	@ApiOperation(value ="Consumes DCC Planet web saervice")
	@ApiResponses({  	
		@ApiResponse(code = 200, message = "OK" ), 
		@ApiResponse(code = 400, message = "Bad Request"),
		@ApiResponse(code = 503, message = "Service unavailable"),
        @ApiResponse(code = 500, message = "Internal server error")})
	@ResponseStatus(value = HttpStatus.OK)
	public Object dccAuthorization(@RequestBody Input input) throws Exception {
		return dccConsultaService.exposePlanet(input);
	}
}
