//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Clase Java para CurrencyConvertibilityEligibilityResponse complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="CurrencyConvertibilityEligibilityResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Merchant" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="ClientCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *                   &lt;element name="DCCProfileID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *                   &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RequestScope" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="MerchantCountry" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="MerchantCurrency" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
 *                   &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="TID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Serial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="POSVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="ClerkID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="TillID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Errors" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Cards" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CurrencyConvertibilityEligibilityResponse", propOrder = {
    "merchant",
    "cards"
})
public class CurrencyConvertibilityEligibilityResponse {

    @XmlElement(name = "Merchant")
    protected CurrencyConvertibilityEligibilityResponse.Merchant merchant;
    @XmlElement(name = "Cards")
    protected ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard cards;

    /**
     * Obtiene el valor de la propiedad merchant.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyConvertibilityEligibilityResponse.Merchant }
     *     
     */
    public CurrencyConvertibilityEligibilityResponse.Merchant getMerchant() {
        return merchant;
    }

    /**
     * Define el valor de la propiedad merchant.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyConvertibilityEligibilityResponse.Merchant }
     *     
     */
    public void setMerchant(CurrencyConvertibilityEligibilityResponse.Merchant value) {
        this.merchant = value;
    }

    /**
     * Obtiene el valor de la propiedad cards.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard }
     *     
     */
    public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard getCards() {
        return cards;
    }

    /**
     * Define el valor de la propiedad cards.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard }
     *     
     */
    public void setCards(ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard value) {
        this.cards = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="ClientCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
     *         &lt;element name="DCCProfileID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
     *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RequestScope" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="MerchantCountry" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="MerchantCurrency" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/&gt;
     *         &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="TID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Serial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="POSVersion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="ClerkID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="TillID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Errors" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "version",
        "clientCode",
        "partnerID",
        "dccProfileID",
        "merchantName",
        "requestScope",
        "merchantCountry",
        "merchantCurrency",
        "msgDateTime",
        "signature",
        "mid",
        "tid",
        "serial",
        "posVersion",
        "clerkID",
        "tillID",
        "errors"
    })
    public static class Merchant {

        @XmlElement(name = "Version")
        protected String version;
        @XmlElement(name = "ClientCode")
        protected String clientCode;
        @XmlElement(name = "PartnerID")
        protected Integer partnerID;
        @XmlElement(name = "DCCProfileID")
        protected Integer dccProfileID;
        @XmlElement(name = "MerchantName")
        protected String merchantName;
        @XmlElement(name = "RequestScope")
        protected int requestScope;
        @XmlElement(name = "MerchantCountry")
        protected int merchantCountry;
        @XmlElement(name = "MerchantCurrency")
        protected int merchantCurrency;
        @XmlElement(name = "MsgDateTime", required = true)
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar msgDateTime;
        @XmlElement(name = "Signature")
        protected String signature;
        @XmlElement(name = "MID")
        protected String mid;
        @XmlElement(name = "TID")
        protected String tid;
        @XmlElement(name = "Serial")
        protected String serial;
        @XmlElement(name = "POSVersion")
        protected String posVersion;
        @XmlElement(name = "ClerkID")
        protected String clerkID;
        @XmlElement(name = "TillID")
        protected String tillID;
        @XmlElement(name = "Errors")
        protected ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode errors;

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersion(String value) {
            this.version = value;
        }

        /**
         * Obtiene el valor de la propiedad clientCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getClientCode() {
            return clientCode;
        }

        /**
         * Define el valor de la propiedad clientCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setClientCode(String value) {
            this.clientCode = value;
        }

        /**
         * Obtiene el valor de la propiedad partnerID.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getPartnerID() {
            return partnerID;
        }

        /**
         * Define el valor de la propiedad partnerID.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setPartnerID(Integer value) {
            this.partnerID = value;
        }

        /**
         * Obtiene el valor de la propiedad dccProfileID.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getDCCProfileID() {
            return dccProfileID;
        }

        /**
         * Define el valor de la propiedad dccProfileID.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setDCCProfileID(Integer value) {
            this.dccProfileID = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMerchantName() {
            return merchantName;
        }

        /**
         * Define el valor de la propiedad merchantName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMerchantName(String value) {
            this.merchantName = value;
        }

        /**
         * Obtiene el valor de la propiedad requestScope.
         * 
         */
        public int getRequestScope() {
            return requestScope;
        }

        /**
         * Define el valor de la propiedad requestScope.
         * 
         */
        public void setRequestScope(int value) {
            this.requestScope = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantCountry.
         * 
         */
        public int getMerchantCountry() {
            return merchantCountry;
        }

        /**
         * Define el valor de la propiedad merchantCountry.
         * 
         */
        public void setMerchantCountry(int value) {
            this.merchantCountry = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantCurrency.
         * 
         */
        public int getMerchantCurrency() {
            return merchantCurrency;
        }

        /**
         * Define el valor de la propiedad merchantCurrency.
         * 
         */
        public void setMerchantCurrency(int value) {
            this.merchantCurrency = value;
        }

        /**
         * Obtiene el valor de la propiedad msgDateTime.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getMsgDateTime() {
            return msgDateTime;
        }

        /**
         * Define el valor de la propiedad msgDateTime.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setMsgDateTime(XMLGregorianCalendar value) {
            this.msgDateTime = value;
        }

        /**
         * Obtiene el valor de la propiedad signature.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSignature() {
            return signature;
        }

        /**
         * Define el valor de la propiedad signature.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSignature(String value) {
            this.signature = value;
        }

        /**
         * Obtiene el valor de la propiedad mid.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMID() {
            return mid;
        }

        /**
         * Define el valor de la propiedad mid.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMID(String value) {
            this.mid = value;
        }

        /**
         * Obtiene el valor de la propiedad tid.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTID() {
            return tid;
        }

        /**
         * Define el valor de la propiedad tid.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTID(String value) {
            this.tid = value;
        }

        /**
         * Obtiene el valor de la propiedad serial.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSerial() {
            return serial;
        }

        /**
         * Define el valor de la propiedad serial.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSerial(String value) {
            this.serial = value;
        }

        /**
         * Obtiene el valor de la propiedad posVersion.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPOSVersion() {
            return posVersion;
        }

        /**
         * Define el valor de la propiedad posVersion.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPOSVersion(String value) {
            this.posVersion = value;
        }

        /**
         * Obtiene el valor de la propiedad clerkID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getClerkID() {
            return clerkID;
        }

        /**
         * Define el valor de la propiedad clerkID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setClerkID(String value) {
            this.clerkID = value;
        }

        /**
         * Obtiene el valor de la propiedad tillID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTillID() {
            return tillID;
        }

        /**
         * Define el valor de la propiedad tillID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTillID(String value) {
            this.tillID = value;
        }

        /**
         * Obtiene el valor de la propiedad errors.
         * 
         * @return
         *     possible object is
         *     {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode }
         *     
         */
        public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode getErrors() {
            return errors;
        }

        /**
         * Define el valor de la propiedad errors.
         * 
         * @param value
         *     allowed object is
         *     {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode }
         *     
         */
        public void setErrors(ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseMerchantErrorNodeErrorNode value) {
            this.errors = value;
        }

    }

}
