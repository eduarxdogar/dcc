package com.credibanco.dcc.dtos;

public class Response {
	private String message;
	private FdvoEligibilityResponse response;
	
	public Response() {
		//Empty
	}
	
	public Response(String message, FdvoEligibilityResponse response) {
		this.message = message;
		this.response = response;
	}
	
	public Response(String message) {
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public FdvoEligibilityResponse getResponse() {
		return response;
	}
	public void setResponse(FdvoEligibilityResponse response) {
		this.response = response;
	}
}
