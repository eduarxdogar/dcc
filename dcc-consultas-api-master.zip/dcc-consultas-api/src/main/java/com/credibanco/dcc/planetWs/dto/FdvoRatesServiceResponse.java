//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PartnerDetails" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="SubgroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RequestScope" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}RequestScopeType"/&gt;
 *                   &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RatesSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="RatesDetails" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="BaseCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RatesProfileID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="RatesBand" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="RatesDays"&gt;
 *                     &lt;simpleType&gt;
 *                       &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *                         &lt;enumeration value="1"/&gt;
 *                         &lt;enumeration value="2"/&gt;
 *                       &lt;/restriction&gt;
 *                     &lt;/simpleType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="RatesRecords" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *                   &lt;element name="Margin" type="{http://www.w3.org/2001/XMLSchema}float"/&gt;
 *                   &lt;element name="Rates" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ErrorNode" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="ErrorCode" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ErrorCodeType"/&gt;
 *                   &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "partnerDetails",
    "ratesDetails",
    "errorNode"
})
@XmlRootElement(name = "FdvoRatesServiceResponse")
public class FdvoRatesServiceResponse {

    @XmlElement(name = "PartnerDetails")
    protected FdvoRatesServiceResponse.PartnerDetails partnerDetails;
    @XmlElement(name = "RatesDetails")
    protected FdvoRatesServiceResponse.RatesDetails ratesDetails;
    @XmlElement(name = "ErrorNode")
    protected FdvoRatesServiceResponse.ErrorNode errorNode;

    /**
     * Obtiene el valor de la propiedad partnerDetails.
     * 
     * @return
     *     possible object is
     *     {@link FdvoRatesServiceResponse.PartnerDetails }
     *     
     */
    public FdvoRatesServiceResponse.PartnerDetails getPartnerDetails() {
        return partnerDetails;
    }

    /**
     * Define el valor de la propiedad partnerDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoRatesServiceResponse.PartnerDetails }
     *     
     */
    public void setPartnerDetails(FdvoRatesServiceResponse.PartnerDetails value) {
        this.partnerDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad ratesDetails.
     * 
     * @return
     *     possible object is
     *     {@link FdvoRatesServiceResponse.RatesDetails }
     *     
     */
    public FdvoRatesServiceResponse.RatesDetails getRatesDetails() {
        return ratesDetails;
    }

    /**
     * Define el valor de la propiedad ratesDetails.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoRatesServiceResponse.RatesDetails }
     *     
     */
    public void setRatesDetails(FdvoRatesServiceResponse.RatesDetails value) {
        this.ratesDetails = value;
    }

    /**
     * Obtiene el valor de la propiedad errorNode.
     * 
     * @return
     *     possible object is
     *     {@link FdvoRatesServiceResponse.ErrorNode }
     *     
     */
    public FdvoRatesServiceResponse.ErrorNode getErrorNode() {
        return errorNode;
    }

    /**
     * Define el valor de la propiedad errorNode.
     * 
     * @param value
     *     allowed object is
     *     {@link FdvoRatesServiceResponse.ErrorNode }
     *     
     */
    public void setErrorNode(FdvoRatesServiceResponse.ErrorNode value) {
        this.errorNode = value;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="ErrorCode" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ErrorCodeType"/&gt;
     *         &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "errorCode",
        "errorMessage"
    })
    public static class ErrorNode {

        @XmlElement(name = "ErrorCode", required = true)
        protected String errorCode;
        @XmlElement(name = "ErrorMessage")
        protected String errorMessage;

        /**
         * Obtiene el valor de la propiedad errorCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getErrorCode() {
            return errorCode;
        }

        /**
         * Define el valor de la propiedad errorCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setErrorCode(String value) {
            this.errorCode = value;
        }

        /**
         * Obtiene el valor de la propiedad errorMessage.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getErrorMessage() {
            return errorMessage;
        }

        /**
         * Define el valor de la propiedad errorMessage.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setErrorMessage(String value) {
            this.errorMessage = value;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="Version" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="PartnerID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="SubgroupID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="MerchantName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RequestScope" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}RequestScopeType"/&gt;
     *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RatesSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="MsgDateTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Signature" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "version",
        "partnerID",
        "subgroupID",
        "merchantName",
        "requestScope",
        "countryCode",
        "ratesSource",
        "msgDateTime",
        "signature",
        "sessionID"
    })
    public static class PartnerDetails {

        @XmlElement(name = "Version")
        protected String version;
        @XmlElement(name = "PartnerID")
        protected int partnerID;
        @XmlElement(name = "SubgroupID")
        protected int subgroupID;
        @XmlElement(name = "MerchantName")
        protected String merchantName;
        @XmlElement(name = "RequestScope", required = true)
        protected String requestScope;
        @XmlElement(name = "CountryCode")
        protected String countryCode;
        @XmlElement(name = "RatesSource")
        protected String ratesSource;
        @XmlElement(name = "MsgDateTime")
        protected String msgDateTime;
        @XmlElement(name = "Signature")
        protected String signature;
        @XmlElement(name = "SessionID")
        protected int sessionID;

        /**
         * Obtiene el valor de la propiedad version.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getVersion() {
            return version;
        }

        /**
         * Define el valor de la propiedad version.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setVersion(String value) {
            this.version = value;
        }

        /**
         * Obtiene el valor de la propiedad partnerID.
         * 
         */
        public int getPartnerID() {
            return partnerID;
        }

        /**
         * Define el valor de la propiedad partnerID.
         * 
         */
        public void setPartnerID(int value) {
            this.partnerID = value;
        }

        /**
         * Obtiene el valor de la propiedad subgroupID.
         * 
         */
        public int getSubgroupID() {
            return subgroupID;
        }

        /**
         * Define el valor de la propiedad subgroupID.
         * 
         */
        public void setSubgroupID(int value) {
            this.subgroupID = value;
        }

        /**
         * Obtiene el valor de la propiedad merchantName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMerchantName() {
            return merchantName;
        }

        /**
         * Define el valor de la propiedad merchantName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMerchantName(String value) {
            this.merchantName = value;
        }

        /**
         * Obtiene el valor de la propiedad requestScope.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRequestScope() {
            return requestScope;
        }

        /**
         * Define el valor de la propiedad requestScope.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRequestScope(String value) {
            this.requestScope = value;
        }

        /**
         * Obtiene el valor de la propiedad countryCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCountryCode() {
            return countryCode;
        }

        /**
         * Define el valor de la propiedad countryCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCountryCode(String value) {
            this.countryCode = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesSource.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRatesSource() {
            return ratesSource;
        }

        /**
         * Define el valor de la propiedad ratesSource.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRatesSource(String value) {
            this.ratesSource = value;
        }

        /**
         * Obtiene el valor de la propiedad msgDateTime.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getMsgDateTime() {
            return msgDateTime;
        }

        /**
         * Define el valor de la propiedad msgDateTime.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setMsgDateTime(String value) {
            this.msgDateTime = value;
        }

        /**
         * Obtiene el valor de la propiedad signature.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSignature() {
            return signature;
        }

        /**
         * Define el valor de la propiedad signature.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSignature(String value) {
            this.signature = value;
        }

        /**
         * Obtiene el valor de la propiedad sessionID.
         * 
         */
        public int getSessionID() {
            return sessionID;
        }

        /**
         * Define el valor de la propiedad sessionID.
         * 
         */
        public void setSessionID(int value) {
            this.sessionID = value;
        }

    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="BaseCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RatesProfileID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="RatesBand" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="RatesDays"&gt;
     *           &lt;simpleType&gt;
     *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
     *               &lt;enumeration value="1"/&gt;
     *               &lt;enumeration value="2"/&gt;
     *             &lt;/restriction&gt;
     *           &lt;/simpleType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="RatesRecords" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
     *         &lt;element name="Margin" type="{http://www.w3.org/2001/XMLSchema}float"/&gt;
     *         &lt;element name="Rates" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "baseCurrencyCode",
        "ratesProfileID",
        "ratesBand",
        "ratesDays",
        "ratesRecords",
        "margin",
        "rates"
    })
    public static class RatesDetails {

        @XmlElement(name = "BaseCurrencyCode")
        protected String baseCurrencyCode;
        @XmlElement(name = "RatesProfileID")
        protected String ratesProfileID;
        @XmlElement(name = "RatesBand")
        protected int ratesBand;
        @XmlElement(name = "RatesDays", required = true)
        protected String ratesDays;
        @XmlElement(name = "RatesRecords")
        protected int ratesRecords;
        @XmlElement(name = "Margin")
        protected float margin;
        @XmlElement(name = "Rates")
        protected ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate rates;

        /**
         * Obtiene el valor de la propiedad baseCurrencyCode.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBaseCurrencyCode() {
            return baseCurrencyCode;
        }

        /**
         * Define el valor de la propiedad baseCurrencyCode.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBaseCurrencyCode(String value) {
            this.baseCurrencyCode = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesProfileID.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRatesProfileID() {
            return ratesProfileID;
        }

        /**
         * Define el valor de la propiedad ratesProfileID.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRatesProfileID(String value) {
            this.ratesProfileID = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesBand.
         * 
         */
        public int getRatesBand() {
            return ratesBand;
        }

        /**
         * Define el valor de la propiedad ratesBand.
         * 
         */
        public void setRatesBand(int value) {
            this.ratesBand = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesDays.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getRatesDays() {
            return ratesDays;
        }

        /**
         * Define el valor de la propiedad ratesDays.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setRatesDays(String value) {
            this.ratesDays = value;
        }

        /**
         * Obtiene el valor de la propiedad ratesRecords.
         * 
         */
        public int getRatesRecords() {
            return ratesRecords;
        }

        /**
         * Define el valor de la propiedad ratesRecords.
         * 
         */
        public void setRatesRecords(int value) {
            this.ratesRecords = value;
        }

        /**
         * Obtiene el valor de la propiedad margin.
         * 
         */
        public float getMargin() {
            return margin;
        }

        /**
         * Define el valor de la propiedad margin.
         * 
         */
        public void setMargin(float value) {
            this.margin = value;
        }

        /**
         * Obtiene el valor de la propiedad rates.
         * 
         * @return
         *     possible object is
         *     {@link ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate }
         *     
         */
        public ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate getRates() {
            return rates;
        }

        /**
         * Define el valor de la propiedad rates.
         * 
         * @param value
         *     allowed object is
         *     {@link ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate }
         *     
         */
        public void setRates(ArrayOfArrayOfFdvoRatesServiceResponseRatesDetailsRateRate value) {
            this.rates = value;
        }

    }

}
