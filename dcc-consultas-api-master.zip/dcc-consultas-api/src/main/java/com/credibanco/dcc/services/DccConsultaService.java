package com.credibanco.dcc.services;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.credibanco.dcc.dtos.Input;
import com.credibanco.dcc.dtos.Response;
import com.fasterxml.jackson.core.JsonProcessingException;

@Service
public interface DccConsultaService {

	ResponseEntity<Response> exposePlanet(Input input) throws JsonProcessingException;

}
