//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantación de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perderán si se vuelve a compilar el esquema de origen. 
// Generado el: 2022.03.28 a las 11:38:01 AM COT 
//


package com.credibanco.dcc.planetWs.dto;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Card" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
 *                   &lt;element name="Eligible" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *                   &lt;element name="IIN" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
 *                   &lt;element name="CardSchemeCode" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/&gt;
 *                   &lt;element name="CardSchemeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="CardDebitType" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *                   &lt;element name="CardCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/&gt;
 *                   &lt;element name="CardCurrencyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="CardCountryCode" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/&gt;
 *                   &lt;element name="CardCountryName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="Errors" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard", propOrder = {
    "card"
})
public class ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard {

    @XmlElement(name = "Card")
    protected List<ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card> card;

    /**
     * Gets the value of the card property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the card property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCard().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card }
     * 
     * 
     */
    public List<ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card> getCard() {
        if (card == null) {
            card = new ArrayList<ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardCard.Card>();
        }
        return this.card;
    }


    /**
     * <p>Clase Java para anonymous complex type.
     * 
     * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="PAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="SessionID" type="{http://www.w3.org/2001/XMLSchema}long"/&gt;
     *         &lt;element name="Eligible" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
     *         &lt;element name="IIN" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/&gt;
     *         &lt;element name="CardSchemeCode" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/&gt;
     *         &lt;element name="CardSchemeName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="CardDebitType" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
     *         &lt;element name="CardCurrencyCode" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/&gt;
     *         &lt;element name="CardCurrencyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="CardCountryCode" type="{http://www.w3.org/2001/XMLSchema}short" minOccurs="0"/&gt;
     *         &lt;element name="CardCountryName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="Errors" type="{http://FdvoWebService.fintrax.com/FdvoSchema.xsd}ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "pan",
        "sessionID",
        "eligible",
        "iin",
        "cardSchemeCode",
        "cardSchemeName",
        "cardDebitType",
        "cardCurrencyCode",
        "cardCurrencyName",
        "cardCountryCode",
        "cardCountryName",
        "errors"
    })
    public static class Card {

        @XmlElement(name = "PAN")
        protected String pan;
        @XmlElement(name = "SessionID")
        protected long sessionID;
        @XmlElement(name = "Eligible")
        protected boolean eligible;
        @XmlElement(name = "IIN")
        protected Long iin;
        @XmlElement(name = "CardSchemeCode")
        protected Short cardSchemeCode;
        @XmlElement(name = "CardSchemeName")
        protected String cardSchemeName;
        @XmlElement(name = "CardDebitType")
        protected Integer cardDebitType;
        @XmlElement(name = "CardCurrencyCode")
        protected Short cardCurrencyCode;
        @XmlElement(name = "CardCurrencyName")
        protected String cardCurrencyName;
        @XmlElement(name = "CardCountryCode")
        protected Short cardCountryCode;
        @XmlElement(name = "CardCountryName")
        protected String cardCountryName;
        @XmlElement(name = "Errors")
        protected ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode errors;

        /**
         * Obtiene el valor de la propiedad pan.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getPAN() {
            return pan;
        }

        /**
         * Define el valor de la propiedad pan.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setPAN(String value) {
            this.pan = value;
        }

        /**
         * Obtiene el valor de la propiedad sessionID.
         * 
         */
        public long getSessionID() {
            return sessionID;
        }

        /**
         * Define el valor de la propiedad sessionID.
         * 
         */
        public void setSessionID(long value) {
            this.sessionID = value;
        }

        /**
         * Obtiene el valor de la propiedad eligible.
         * 
         */
        public boolean isEligible() {
            return eligible;
        }

        /**
         * Define el valor de la propiedad eligible.
         * 
         */
        public void setEligible(boolean value) {
            this.eligible = value;
        }

        /**
         * Obtiene el valor de la propiedad iin.
         * 
         * @return
         *     possible object is
         *     {@link Long }
         *     
         */
        public Long getIIN() {
            return iin;
        }

        /**
         * Define el valor de la propiedad iin.
         * 
         * @param value
         *     allowed object is
         *     {@link Long }
         *     
         */
        public void setIIN(Long value) {
            this.iin = value;
        }

        /**
         * Obtiene el valor de la propiedad cardSchemeCode.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getCardSchemeCode() {
            return cardSchemeCode;
        }

        /**
         * Define el valor de la propiedad cardSchemeCode.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setCardSchemeCode(Short value) {
            this.cardSchemeCode = value;
        }

        /**
         * Obtiene el valor de la propiedad cardSchemeName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCardSchemeName() {
            return cardSchemeName;
        }

        /**
         * Define el valor de la propiedad cardSchemeName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCardSchemeName(String value) {
            this.cardSchemeName = value;
        }

        /**
         * Obtiene el valor de la propiedad cardDebitType.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getCardDebitType() {
            return cardDebitType;
        }

        /**
         * Define el valor de la propiedad cardDebitType.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setCardDebitType(Integer value) {
            this.cardDebitType = value;
        }

        /**
         * Obtiene el valor de la propiedad cardCurrencyCode.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getCardCurrencyCode() {
            return cardCurrencyCode;
        }

        /**
         * Define el valor de la propiedad cardCurrencyCode.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setCardCurrencyCode(Short value) {
            this.cardCurrencyCode = value;
        }

        /**
         * Obtiene el valor de la propiedad cardCurrencyName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCardCurrencyName() {
            return cardCurrencyName;
        }

        /**
         * Define el valor de la propiedad cardCurrencyName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCardCurrencyName(String value) {
            this.cardCurrencyName = value;
        }

        /**
         * Obtiene el valor de la propiedad cardCountryCode.
         * 
         * @return
         *     possible object is
         *     {@link Short }
         *     
         */
        public Short getCardCountryCode() {
            return cardCountryCode;
        }

        /**
         * Define el valor de la propiedad cardCountryCode.
         * 
         * @param value
         *     allowed object is
         *     {@link Short }
         *     
         */
        public void setCardCountryCode(Short value) {
            this.cardCountryCode = value;
        }

        /**
         * Obtiene el valor de la propiedad cardCountryName.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getCardCountryName() {
            return cardCountryName;
        }

        /**
         * Define el valor de la propiedad cardCountryName.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setCardCountryName(String value) {
            this.cardCountryName = value;
        }

        /**
         * Obtiene el valor de la propiedad errors.
         * 
         * @return
         *     possible object is
         *     {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode }
         *     
         */
        public ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode getErrors() {
            return errors;
        }

        /**
         * Define el valor de la propiedad errors.
         * 
         * @param value
         *     allowed object is
         *     {@link ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode }
         *     
         */
        public void setErrors(ArrayOfArrayOfCurrencyConvertibilityEligibilityResponseCardErrorNodeErrorNode value) {
            this.errors = value;
        }

    }

}
