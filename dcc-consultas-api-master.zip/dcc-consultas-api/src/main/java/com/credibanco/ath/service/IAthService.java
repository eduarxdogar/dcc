package com.credibanco.ath.service;

import com.credibanco.dcc.planetWs.dto.VatDccRequest;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface IAthService {
	
	public Object updateInformactionTerminal(VatDccRequest request) throws JsonProcessingException;
	
}
